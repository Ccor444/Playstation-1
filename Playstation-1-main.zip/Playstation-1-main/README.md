# Playstation 1 HTML5
🚧 **Aviso Importante**  
O emulador
basta abrir o arquivo `index.html` direto no seu computador ou celular que o sistema inicializa normalmente.

Este projeto visa emular o console PlayStation 1 diretamente no navegador, utilizando tecnologias web modernas.

## 🎮 Sobre o Projeto

O objetivo é proporcionar uma experiência de jogo clássica do PS1 em dispositivos modernos, sem a necessidade de plugins ou instalações adicionais.

## 👨‍💻 Créditos

Este projeto é inspirado no trabalho de [Kootstra Rene](https://github.com/kootstra-rene/enge-js), que desenvolveu o emulador PS1 em JavaScript. Seu esforço e dedicação serviram como base para este projeto.


